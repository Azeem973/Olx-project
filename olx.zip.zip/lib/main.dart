import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

import 'package:firebase_cli/loginScreen.dart';
import 'package:firebase_cli/splash_screen.dart';
import 'package:widget_and_text_animator/widget_and_text_animator.dart';



void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {

    //we will make splash screen first we need package
    return FutureBuilder(future: Future.delayed(Duration(seconds: 5)),
      builder: (context, AsyncSnapshot snapshot){

        //show splash screen while waiting for the app resources to load
        if(snapshot.connectionState==ConnectionState.waiting){
          return MaterialApp(
            // To remove banner
            debugShowCheckedModeBanner: false,
            home: splashScreen(),);
        }
        else{
          //loading done return the app
          return MaterialApp(
            home: loginscreen(),
          );
        }
      },
    );
  }
}



